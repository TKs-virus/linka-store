export default function MinimalPage() {
  return <h1>Minimal Page Working</h1>;
}

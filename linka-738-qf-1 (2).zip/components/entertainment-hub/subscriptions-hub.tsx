// Using the same content as previously created
export { SubscriptionsSection as SubscriptionsHub } from "@/components/entertainment/subscriptions-section"
